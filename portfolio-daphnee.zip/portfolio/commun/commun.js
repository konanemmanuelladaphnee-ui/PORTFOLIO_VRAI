/* Interactions communes : menu ancré, dropdowns, apparition au défilement */
(function () {
  "use strict";

  var nav = document.getElementById("nav");
  var progress = document.querySelector(".nav__progress");
  var burger = document.querySelector(".burger");
  var menu = document.getElementById("menu");
  var items = Array.prototype.slice.call(document.querySelectorAll(".menu__item"));
  var indicator = document.querySelector(".menu__indicator");
  var desktop = window.matchMedia("(min-width: 901px)");

  /* --- Réaction au défilement : menu condensé + barre de progression --- */
  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop;
    nav.classList.toggle("is-scrolled", y > 24);
    var max = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = (max > 0 ? Math.min(100, (y / max) * 100) : 0) + "%";
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* --- Indicateur coulissant qui suit le survol / le focus --- */
  function moveIndicator(link) {
    if (!indicator || !desktop.matches) return;
    if (!link) { indicator.style.opacity = "0"; return; }
    var list = indicator.parentElement.getBoundingClientRect();
    var r = link.getBoundingClientRect();
    indicator.style.opacity = "1";
    indicator.style.width = r.width - 28 + "px";
    indicator.style.transform = "translateX(" + (r.left - list.left + 14) + "px)";
  }
  function resetIndicator() { moveIndicator(document.querySelector(".menu__link.is-active")); }

  items.forEach(function (item) {
    var link = item.querySelector(".menu__link");
    item.addEventListener("mouseenter", function () { moveIndicator(link); });
    link.addEventListener("focus", function () { moveIndicator(link); });
  });
  if (menu) menu.addEventListener("mouseleave", resetIndicator);
  window.addEventListener("resize", resetIndicator);
  window.addEventListener("load", resetIndicator);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(resetIndicator);
  resetIndicator();

  /* --- Dropdowns : survol (bureau), clic et clavier --- */
  function closeAll(except) {
    items.forEach(function (item) {
      if (item === except) return;
      item.classList.remove("is-open");
      var t = item.querySelector(".drop-toggle");
      if (t) t.setAttribute("aria-expanded", "false");
    });
  }
  function setOpen(item, open) {
    if (open) closeAll(item);
    item.classList.toggle("is-open", open);
    var t = item.querySelector(".drop-toggle");
    if (t) t.setAttribute("aria-expanded", String(open));
  }

  items.forEach(function (item) {
    var toggle = item.querySelector(".drop-toggle");
    if (!toggle) return;
    var timer;
    toggle.addEventListener("click", function (e) {
      e.stopPropagation();
      setOpen(item, !item.classList.contains("is-open"));
    });
    item.addEventListener("mouseenter", function () {
      if (!desktop.matches) return;
      clearTimeout(timer);
      setOpen(item, true);
    });
    item.addEventListener("mouseleave", function () {
      if (!desktop.matches) return;
      timer = setTimeout(function () { setOpen(item, false); }, 160);
    });
    item.addEventListener("focusout", function (e) {
      if (desktop.matches && !item.contains(e.relatedTarget)) setOpen(item, false);
    });
  });

  document.addEventListener("click", function (e) {
    if (!e.target.closest(".menu__item")) closeAll();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    closeAll();
    if (menu.classList.contains("is-open")) toggleMenu(false);
  });

  /* --- Menu mobile --- */
  function toggleMenu(open) {
    menu.classList.toggle("is-open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
  }
  if (burger) {
    burger.addEventListener("click", function () {
      toggleMenu(!menu.classList.contains("is-open"));
    });
  }
  /* Ferme le menu après un clic sur un lien (utile pour les ancres de la même page) */
  menu.addEventListener("click", function (e) {
    if (e.target.closest("a")) { closeAll(); toggleMenu(false); }
  });

  /* --- Apparition des blocs au défilement --- */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add("is-in"); io.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("is-in"); });
  }

  /* --- Année du pied de page --- */
  var year = document.getElementById("annee");
  if (year) year.textContent = new Date().getFullYear();
})();
