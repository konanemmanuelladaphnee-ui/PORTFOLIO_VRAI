/* Formulaire de contact : validation puis ouverture du logiciel de messagerie */
(function () {
  "use strict";

  var form = document.getElementById("contact-form");
  if (!form) return;
  var status = document.getElementById("form-status");
  var objet = form.elements.objet;

  /* Pré-sélection de l'objet depuis l'URL (ex. contacts.html?objet=partenariat) */
  var voulu = new URLSearchParams(window.location.search).get("objet");
  if (voulu && objet.querySelector('option[value="' + voulu.replace(/[^a-z]/g, "") + '"]')) {
    objet.value = voulu;
  }

  var regles = {
    nom: function (v) { return v.trim().length >= 2; },
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()); },
    objet: function (v) { return v !== ""; },
    message: function (v) { return v.trim().length >= 10; }
  };

  function verifier(nom) {
    var champ = form.elements[nom];
    var ok = regles[nom](champ.value);
    var erreur = document.getElementById(nom + "-erreur");
    champ.closest(".field").classList.toggle("is-invalid", !ok);
    champ.setAttribute("aria-invalid", String(!ok));
    if (ok) champ.removeAttribute("aria-describedby");
    else champ.setAttribute("aria-describedby", nom + "-erreur");
    erreur.hidden = ok;
    return ok;
  }

  Object.keys(regles).forEach(function (nom) {
    form.elements[nom].addEventListener("blur", function () { verifier(nom); });
    form.elements[nom].addEventListener("input", function () {
      if (form.elements[nom].closest(".field").classList.contains("is-invalid")) verifier(nom);
    });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var invalides = Object.keys(regles).filter(function (nom) { return !verifier(nom); });
    if (invalides.length) {
      status.textContent = "Certains champs sont à corriger.";
      status.classList.add("is-error");
      form.elements[invalides[0]].focus();
      return;
    }

    var d = form.elements;
    var libelle = d.objet.options[d.objet.selectedIndex].text;
    var corps = [
      "Nom : " + d.nom.value.trim(),
      "E-mail : " + d.email.value.trim(),
      "Téléphone : " + (d.telephone.value.trim() || "non renseigné"),
      "",
      d.message.value.trim()
    ].join("\n");

    window.location.href = "mailto:" + form.dataset.email +
      "?subject=" + encodeURIComponent("[Portfolio] " + libelle) +
      "&body=" + encodeURIComponent(corps);

    status.classList.remove("is-error");
    status.textContent = "Votre logiciel de messagerie s'ouvre avec le message prêt à envoyer.";
  });
})();
